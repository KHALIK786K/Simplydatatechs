/**
 * Central branding + site metadata.
 * Change values here to rebrand the whole app in one place.
 */
export const site = {
  name: "Simplidatatechs",
  domain: "simplidatatechs.com",
  url: "https://www.simplidatatechs.com",
  tagline: "Online Programs to Advance Your Career",
  description:
    "Simplidatatechs offers industry-aligned online programs in data, analytics, management, and software — with live sessions, projects, and career support.",
  email: "info@simplidatatechs.com",
  phone: "+91-99900-56233, +91-88001-28981",
  address: "Gurugram, Haryana, India",
  social: {
    linkedin: "https://www.linkedin.com/company/simplidatatechs",
    twitter: "https://twitter.com/simplidatatechs",
    youtube: "https://www.youtube.com/@simplidatatechs",
    instagram: "https://www.instagram.com/simplidatatechs",
  },
  founded: 2019,
} as const;

export type SiteConfig = typeof site;
