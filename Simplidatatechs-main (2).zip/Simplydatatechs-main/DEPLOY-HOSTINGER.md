# Deploying Simplidatatechs to Hostinger

This is a static single-page app (React + Vite). All course data is served
from an in-memory mock layer, so **no backend or database is required** — you
only need to upload the built static files.

---

## 1. Build the site locally

You need Node.js 18+ installed (the repo pins Node 20 via `.nvmrc`).

```bash
npm install
npm run build
```

This produces a `dist/` folder. That folder — and everything inside it — is
what gets deployed. It already includes `.htaccess` (copied from `public/`),
which is required for routing to work.

Optional — preview the production build before uploading:

```bash
npm run preview
```

---

## 2. Upload to Hostinger

Pick whichever method you prefer.

### Option A — hPanel File Manager (simplest)

1. Log in to Hostinger → **hPanel** → **Files → File Manager**.
2. Open the `public_html` folder of your domain.
3. Delete the default placeholder (e.g. `default.php` / `index.html`) if present.
4. Upload the **contents of `dist/`** (not the `dist` folder itself) into
   `public_html`. The structure should look like:
   ```
   public_html/
     ├── index.html
     ├── .htaccess
     ├── favicon.svg
     ├── og-image.svg
     ├── robots.txt
     ├── sitemap.xml
     └── assets/…
   ```
5. **Check that `.htaccess` uploaded.** File Manager hides dotfiles by default —
   enable "show hidden files" in its settings. If it's missing, upload
   `public/.htaccess` manually into `public_html`.

### Option B — FTP (FileZilla)

1. hPanel → **Files → FTP Accounts** to get host, username, password.
2. Connect with FileZilla and upload the contents of `dist/` into `public_html`.
3. Make sure hidden files are shown (FileZilla → Server → *Force showing hidden files*)
   so `.htaccess` transfers.

### Option C — Git deployment (if your plan supports it)

hPanel → **Advanced → Git**. Point it at your repository. Note that Hostinger's
Git deploy pulls the repo as-is; for a Vite app you still need the built output
in `public_html`, so either commit `dist/` or run the build step your plan
provides. Most users find Option A/B simpler.

---

## 3. Enable HTTPS

1. hPanel → **Security → SSL** and install the free SSL certificate for your
   domain (if not already active).
2. The included `.htaccess` already forces HTTPS. If you'd rather manage the
   redirect from hPanel, comment out the "Force HTTPS" block in `.htaccess`.

---

## 4. Point your domain

If your domain is registered with Hostinger it's linked automatically. If it's
elsewhere, update the nameservers or DNS A record to Hostinger per their
domain-connection guide, then wait for propagation.

---

## What the `.htaccess` does

- **SPA routing** — rewrites any non-file request to `index.html` so deep links
  and refreshes on `/courses`, `/contact`, etc. work instead of 404ing.
- **Forces HTTPS**.
- **Compression** (gzip) for text, JS, CSS, JSON, SVG.
- **Caching** — hashed build assets cached for a year; `index.html` never cached
  so visitors always get the newest deploy.
- **Security headers** — `X-Content-Type-Options`, `X-Frame-Options`,
  `Referrer-Policy`, `Permissions-Policy`.

---

## Deploying into a subfolder (e.g. `example.com/app/`)

The default config assumes the domain root. For a subfolder:

1. In `vite.config.ts`, set `base: "/app/"`.
2. Give the router a matching `basename="/app"`.
3. In `.htaccess`, set `RewriteBase /app/` and the fallback to
   `RewriteRule ^ /app/index.html [L]`.

---

## Updating the site later

Re-run `npm run build` and re-upload the contents of `dist/`. Because
`index.html` is set to never cache, visitors pick up the new hashed assets
immediately.
